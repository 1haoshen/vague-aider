# 本地跑 MobileWorld L1/L2/L3 评测 —— 拷贝包安装说明

这个包**只含我们的自定义文件**（runner / 数据集 / 配置 / 文档）。
MobileWorld 评测环境本身体积大且和平台相关（.venv 不能跨机拷），
在本地机器上重新 clone + `uv sync` 重建。

## 目录结构（解压后）

把本包解压到你本地的**项目根目录**（下面记作 `<repo>`），会得到：
```
<repo>/
├── COPY_README.md                              ← 本文件
├── Mobile-Agent-E/instr_rewrite/
│   ├── mw_eval_runner.py                       ← 评测主脚本
│   ├── expand_vague_ins.py                     ← 数据集生成器（要重建数据集时用）
│   ├── mw_setup_check.sh                        ← 机器体检
│   └── MW_EVAL_RUNBOOK.md                       ← 完整操作手册
├── app-data/
│   ├── Ins-bench/Vague-ins-expanded.json       ← 103 条数据集（含 50 条 MW）
│   ├── Ins-bench/Vague-ins.json                ← 原始 50 条（生成器输入）
│   └── knowledge-base/AppUi-final.json         ← 115-app 知识库（重建时用）
└── MobileWorld/MobileWorld/.env                ← key 配置（确认 sk- 前缀）
```

> ⚠️ runner 用相对路径定位：它在 `<repo>/Mobile-Agent-E/instr_rewrite/`，
> MobileWorld 必须在 `<repo>/MobileWorld/MobileWorld/`。务必保持这个层级。

## 安装步骤

```bash
cd <repo>

# 1. clone MobileWorld 到指定层级，并对齐我们用的版本（保证任务文件/类名一致）
git clone https://github.com/Tongyi-MAI/MobileWorld.git MobileWorld/MobileWorld
cd MobileWorld/MobileWorld
git checkout 9cb125b1b3e057b629381b90d6302c6fc48231d7   # 我们这边的 commit

# 2. 装依赖（建 .venv + mw CLI）
uv sync

# 3. 把 .env 放回（解压时已带，确认在 MobileWorld/MobileWorld/.env）
#    注意 DASHSCOPE_API_KEY 应为 sk- 开头

# 4. 体检（KVM 必须 ✓，本地物理机+BIOS开虚拟化才行）
cd <repo>
bash Mobile-Agent-E/instr_rewrite/mw_setup_check.sh
```

## 跑评测

详见 `Mobile-Agent-E/instr_rewrite/MW_EVAL_RUNBOOK.md`。两个终端：

```bash
# 终端 A：起 emulator（保持运行）
cd <repo>/MobileWorld/MobileWorld
.venv/bin/mw env run --count 5 --launch-interval 20

# 终端 B：跑 L1/L2/L3
cd <repo>
python Mobile-Agent-E/instr_rewrite/mw_eval_runner.py \
    --agent general_e2e --model-name gpt-5.5 \
    --llm-base-url https://api.apiyi.com/v1 --api-key sk-<apiyi-key> \
    --enable-mcp --enable-user-interaction \
    --levels L1,L2,L3 --max-concurrency 5
```

结果在 `app-data/Ins-bench/mw_eval_results/`。

## 关于 git（之前 403 的原因）

`MobileWorld/MobileWorld` 是从别人的官方仓库 clone 的，你没写权限，所以
往它 push 会 403。要做版本管理就把**你自己这套**（vague-aider）推到**你自己的**
GitHub 仓库，MobileWorld 当作外部依赖（clone，不纳入你的提交，或设为 submodule）。
